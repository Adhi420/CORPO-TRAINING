# Dictionaries in Python
student = {"name": "John", "age": 20, "course": "CS"}
print("Student Name:", student["name"])
