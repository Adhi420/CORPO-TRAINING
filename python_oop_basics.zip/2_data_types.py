# Data Types in Python
a = 10            # int
b = 3.14          # float
c = "Hello"       # str
d = True          # bool

print(type(a), type(b), type(c), type(d))
