# Loops in Python
print("For Loop Example:")
for i in range(5):
    print("i =", i)

print("\nWhile Loop Example:")
count = 0
while count < 3:
    print("Count is", count)
    count += 1
