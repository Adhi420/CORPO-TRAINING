# Functions in Python
def greet(name):
    return "Hello, " + name

print(greet("Alice"))
