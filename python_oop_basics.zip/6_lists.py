# Lists in Python
fruits = ["apple", "banana", "cherry"]
fruits.append("orange")
print("Fruit List:", fruits)
